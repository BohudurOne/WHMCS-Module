<?php
exit("what you are trying to do?");
?>